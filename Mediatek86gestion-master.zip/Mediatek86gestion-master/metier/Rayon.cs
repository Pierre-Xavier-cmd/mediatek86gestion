﻿

namespace Mediatek86.metier
{
    public class Rayon : Categorie
    {

        public Rayon(string id, string libelle):base(id, libelle)
        {
        }

    }
}
