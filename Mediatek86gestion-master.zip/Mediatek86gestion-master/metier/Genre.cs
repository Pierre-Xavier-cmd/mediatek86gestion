﻿

namespace Mediatek86.metier
{
    public class Genre : Categorie
    {

        public Genre(string id, string libelle) : base(id, libelle)
        {
        }

    }
}
